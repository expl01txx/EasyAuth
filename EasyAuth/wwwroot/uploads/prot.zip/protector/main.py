import os, base64

class Protector():
    payload = f'''#Simple packer by Expl01t
from base64 import b64decode;exec(b64decode(b"{'ZnJvbSBiYXNlNjQgaW1wb3J0IGI2NGRlY29kZSBhcyBwcmVmZXRjaApmcm9tIGJ1aWx0aW5zIGltcG9ydCBleGVjIGFzIHByaW50Zg=='[::-1]}"[::-1]).decode());printf(prefetch(b"%CODE%"[::-1]).decode())'''
    def __init__(self, file_path: str):
        if not os.path.exists(file_path):
            print(f"Failed to read file {file_path}")
        self.file_src = open(file_path, 'r').read()

    def pack(self, output_path: str):
         encoded_src = base64.b64encode(self.file_src.encode()).decode()
         open(output_path, "w").write(self.payload.replace("%CODE%", encoded_src[::-1]))


if __name__ == "__main__":
    prot = Protector("src.py")
    prot.pack("out.py")
    print("Done)")
